Pour compiler :
make
Pour nettoyer : 
make clean
Pour executer : 
./Main